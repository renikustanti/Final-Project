from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators import PythonOperator
import os
from airflow.hooks import PostgresHook
import json
import numpy as np


def load_data(ds, **kwargs):
	

	pg_hook  = PostgresHook(postgres_conn_id='flights_id')

	file_name = str(datetime.now().date()) + '.csv'
	tot_name = os.path.join(os.path.dirname(__file__),'src/data', file_name)


	with open(tot_name, 'r') as inputfile:
		doc = csv.load(inputfile)


	YEAR       				    = int(doc['year'])
	MONTH   				    = int(doc['month'])
	DAY       				    = int(doc['day'])
	AIRLINE   			        = str(doc['id'])
	FLIGHT_NUMBER		        = str(doc['kode penerbangan'])
	ORIGIN_AIRPORT      		= str(doc['kode bandara'])
	DESTINATION_AIPORT   		= str(doc['kode bandara tujuan'])
	SCHEDULLED_DEPARTURE 	    = str(doc['waktu rencana berangkat']) - (HH:MM)
	DEPARTURE_TIME       		= str(doc['waktu berangkat']) - (HH:MM)
	SCHEDULLED_ARRIVAL   		= str(doc['waktu rencana kedatangan']) - (HH:MM)
	ARRIVAL_TIME 				= str(doc['waktu kedatangan']) - (HH:MM)
	CANCELLED      				= bool(doc['true or false'])
	CANCELLATION_RSCHEDULLED    = str(doc['reason']['description'])
	


	valid_data  = True
	for valid in np.isnan(AIRLINE, FLIGHT_NUMBER, ORIGIN_AIRPORT, DESTINATION_AIPORT, SCHEDULLED_DEPARTURE, DEPARTURE_TIME, SCHEDULLED_ARRIVAL, ARRIVAL_TIME, CANCELLED, CANCELLATION_RSCHEDULLED ]):
		if valid is False:
			valid_data = False
			break;

	row  =  (AIRLINE, FLIGHT_NUMBER, ORIGIN_AIRPORT, DESTINATION_AIPORT, SCHEDULLED_DEPARTURE,
			DEPARTURE_TIME, SCHEDULLED_ARRIVAL, ARRIVAL_TIME, CANCELLED, CANCELLATION_RSCHEDULLED)

	insert_cmd = """INSERT INTO flights_table 
					(AIRLINE, FLIGHT_NUMBER, ORIGIN_AIRPORT,
					DESTINATION_AIPORT, SCHEDULLED_DEPARTURE,
					DEPARTURE_TIME, SCHEDULLED_ARRIVAL, ARRIVAL_TIME, 
					CANCELLED, CANCELLATION_RSCHEDULLED)
					VALUES
					(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""

	if valid_data is True:
		pg_hook.run(insert_cmd, parameters=row)


# Define the default dag arguments.
default_args = {
		'owner' : 'digitalskola',
		'depends_on_past' :False,
		'email' :['renkustanti@gmail.com'],
		'email_on_failure': False,
		'email_on_retry': False,
		'retries': 5,
		'retry_delay': timedelta(minutes=1)
		}



dag = DAG(
		dag_id='flightsDag',
		default_args=default_args,
		start_date=datetime(2021,7,15),
		schedule_interval=timedelta(minutes=1440))



task1 = BashOperator(
			task_id='get_flights',
			bash_command='python ~/airflow/dags/src/getWeather.py' ,
			dag=dag)



task2 =  PythonOperator(
			task_id='transform_load',
			provide_context=True,
			python_callable=load_data,
			dag=dag)


task1 >> task2 

